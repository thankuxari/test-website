<?php

    include("headerNavbar.php")

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Skateshop || Home</title>
</head>
<body>
    <div class="navbar-text d-flex justify-content-around">
            <p class="bi bi-telephone-fill"> 2106954093</p>
            <p class="bi bi-truck"> ΔΩΡΕΑΝ ΜΕΤΑΦΟΡΙΚΑ ΜΕ ΑΓΟΡΕΣ ΠΑΝΩ ΑΠΟ 80€</p>
            <p>Greek</p>
    </div>
    <div class="container d-flex justify-content-center align-content-center mt-5">
        <div class="row justify-content-center small-collapse medium-uncollapse large-uncollapse">
            <div class="col-lg-8">
                <a href="#"><img class="firstimage" src="images/NIKE-SB-Shane-Wear-Test-Review-Unboxing-04.jpg"></a>
            </div>
            <div class="col-sm-2 d-flex flex-column justify-content-between align-items-center">
                <a href="#"><img  class="secondimage" src="images/3fc4dbf30f6635602f358d54bb6f987e.jpg"></a>
                <a href="#"><img src="images/16152_Comp_J_2_Image.jpg"></a>
            </div>
        </div>
    </div>
</body>
<?php

    include('footer.php')

?>
</html>
