<?php
    
    include('header.php');

?>

<footer>
    <div class="container p-5">
        <div class="row justify-content-center">
            <div class="col-md-2 col-sm-4 p-1">
                <a class="nav-link"href="#"><i class='bi bi-truck'></i><p>Τρόποι Παραγγελίας</p></a>
            </div>
            <div class="col-md-2 col-sm-4 p-1">
                <a class="nav-link" href="#"><i class="bi bi-cash"></i><p>Τρόποι Πληρωμής</p></a>
            </div>
            <div class="col-md-2 col-sm-4 p-1">
                <a class="nav-link" href="#"><i class="bi bi-send"></i><p>Τρόποι Αποστολής</p></a>
            </div>
            <div class="col-md-2 col-sm-4 p-1">
                <a class="nav-link" href="#"><i class="bi bi-cash"></i><p>Παρακολούθηση Παραγγελίας</p></a>
            </div>
            <div class="col-md-2 col-sm-4 p-1">
                <a class="nav-link" href="#"><i class="bi bi-cash"></i><p>Επιστροφές Προϊόντων</p></a>
            </div>
        </div>
        <div class="row trustcontainer justify-content-center d-flex justify-content-around">
            <div class="title">
                <h4>Γιατί να μας επιλέξετε</h4>
            </div>
            <div class="col-md-2 d-flex flex-column align-items-center">
                <i class="bi bi-tag" style="font-size:35px"></i><p>Ανταγωνιστικές Τιμές</p>
            </div>
            <div class="col-md-2 d-flex flex-column align-items-center">
                <i class="bi bi-truck" style="font-size:35px"></i><p>Γρήγορες Παραδόσεις</p>
            </div>
            <div class="col-md-2 d-flex flex-column align-items-center">
                <i class="bi bi-coin" style="font-size:35px"></i><p>Επιστροφή Χρημάτων</p>
            </div>
            <div class="col-md-2 d-flex flex-column align-items-center">
                <i class="bi bi-award" style="font-size:35px"></i><p>100% Αυθεντικά Προϊόντα</p>
            </div>
        </div>
    </div>
</footer>